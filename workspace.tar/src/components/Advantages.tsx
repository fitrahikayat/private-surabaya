import { Shield, Clock, MapPin, BadgeCheck, MessageCircle, TrendingUp } from 'lucide-react';

export default function Advantages() {
  const advantages = [
    {
      icon: MapPin,
      title: 'Guru Datang ke Rumah',
      description: 'Tidak perlu repot bepergian. Guru datang langsung ke rumah murid di seluruh area Surabaya dan sekitarnya.',
    },
    {
      icon: BadgeCheck,
      title: 'Guru Berkualitas',
      description: 'Guru kami lulusan universitas terbaik dengan pengalaman mengajar minimal 2 tahun dan telah melalui seleksi ketat.',
    },
    {
      icon: Clock,
      title: 'Jadwal Fleksibel',
      description: 'Atur jadwal belajar sesuai kesibukan. Bisa pagi, siang, sore, atau malam. Bisa ganti jadwal dengan mudah.',
    },
    {
      icon: TrendingUp,
      title: 'Progress Terukur',
      description: 'Laporan progress belajar dikirim secara berkala ke orang tua. Pantau perkembangan anak dengan mudah.',
    },
    {
      icon: Shield,
      title: 'Garansi Kepuasan',
      description: 'Tidak cocok dengan guru? Kami akan ganti guru baru tanpa biaya tambahan. Kepuasan murid adalah prioritas.',
    },
    {
      icon: MessageCircle,
      title: 'Komunikasi Aktif',
      description: 'Grup WhatsApp dengan guru dan tim kami untuk komunikasi yang lancar seputar perkembangan belajar.',
    },
  ];

  return (
    <section id="keunggulan" className="py-20 lg:py-28 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <span className="inline-block bg-primary-100 text-primary-700 px-4 py-1.5 rounded-full text-sm font-semibold mb-4">
            Keunggulan Kami
          </span>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-gray-900 mb-6">
            Kenapa Harus <span className="text-gradient">Private Surabaya</span>?
          </h2>
          <p className="text-lg text-gray-600">
            Kami memberikan layanan terbaik untuk memastikan pengalaman belajar yang optimal
          </p>
        </div>

        {/* Advantages Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {advantages.map((item, index) => (
            <div
              key={index}
              className="bg-white rounded-2xl p-8 border border-gray-100 hover:shadow-lg transition-all duration-300 hover:-translate-y-1"
            >
              <div className="w-12 h-12 bg-primary-100 rounded-xl flex items-center justify-center mb-5">
                <item.icon className="w-6 h-6 text-primary-600" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-3">{item.title}</h3>
              <p className="text-gray-600 leading-relaxed">{item.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
