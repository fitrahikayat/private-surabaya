import { Check, Star } from 'lucide-react';

export default function Pricing() {
  const plans = [
    {
      name: 'Reguler',
      price: '80.000',
      unit: '/pertemuan',
      description: 'Cocok untuk belajar rutin mingguan',
      features: [
        '1x pertemuan (90 menit)',
        'Guru datang ke rumah',
        'Materi sesuai permintaan',
        'Laporan progress bulanan',
        'Konsultasi via WhatsApp',
      ],
      popular: false,
      color: 'border-gray-200',
    },
    {
      name: 'Intensif',
      price: '70.000',
      unit: '/pertemuan',
      description: 'Paket hemat untuk belajar lebih sering',
      features: [
        'Min. 8x pertemuan/bulan',
        'Guru datang ke rumah',
        'Materi sesuai permintaan',
        'Laporan progress mingguan',
        'Konsultasi via WhatsApp',
        'Try Out / Latihan soal',
        'Prioritas jadwal',
      ],
      popular: true,
      color: 'border-primary-500',
    },
    {
      name: 'Premium',
      price: '100.000',
      unit: '/pertemuan',
      description: 'Untuk persiapan khusus & intensif',
      features: [
        '1x pertemuan (120 menit)',
        'Guru senior berpengalaman',
        'Materi sesuai permintaan',
        'Laporan progress mingguan',
        'Konsultasi via WhatsApp',
        'Modul belajar eksklusif',
        'Evaluasi & bedah soal',
        'Garansi ganti guru',
      ],
      popular: false,
      color: 'border-gray-200',
    },
  ];

  return (
    <section id="harga" className="py-20 lg:py-28 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <span className="inline-block bg-primary-100 text-primary-700 px-4 py-1.5 rounded-full text-sm font-semibold mb-4">
            Paket Harga
          </span>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-gray-900 mb-6">
            Harga <span className="text-gradient">Terjangkau</span>
          </h2>
          <p className="text-lg text-gray-600">
            Pilih paket yang sesuai dengan kebutuhan dan budget. Semua paket sudah termasuk guru datang ke rumah.
          </p>
        </div>

        {/* Pricing Cards */}
        <div className="grid md:grid-cols-3 gap-8 max-w-5xl mx-auto">
          {plans.map((plan, index) => (
            <div
              key={index}
              className={`relative bg-white rounded-2xl p-8 border-2 ${plan.color} hover:shadow-xl transition-all duration-300 ${
                plan.popular ? 'shadow-lg scale-105' : ''
              }`}
            >
              {plan.popular && (
                <div className="absolute -top-4 left-1/2 -translate-x-1/2 bg-primary-600 text-white px-4 py-1 rounded-full text-sm font-semibold flex items-center gap-1">
                  <Star className="w-3 h-3 fill-white" />
                  Paling Populer
                </div>
              )}

              <div className="text-center mb-8">
                <h3 className="text-xl font-bold text-gray-900 mb-2">{plan.name}</h3>
                <p className="text-sm text-gray-500 mb-4">{plan.description}</p>
                <div className="flex items-baseline justify-center gap-1">
                  <span className="text-sm text-gray-500">Rp</span>
                  <span className="text-4xl font-extrabold text-gray-900">{plan.price}</span>
                </div>
                <span className="text-sm text-gray-500">{plan.unit}</span>
              </div>

              <ul className="space-y-3 mb-8">
                {plan.features.map((feature, i) => (
                  <li key={i} className="flex items-start gap-3">
                    <Check className="w-5 h-5 text-green-500 flex-shrink-0 mt-0.5" />
                    <span className="text-sm text-gray-600">{feature}</span>
                  </li>
                ))}
              </ul>

              <a
                href="#kontak"
                className={`block text-center py-3 rounded-xl font-semibold transition-all ${
                  plan.popular
                    ? 'bg-primary-600 text-white hover:bg-primary-700 shadow-lg shadow-primary-600/25'
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
              >
                Pilih Paket
              </a>
            </div>
          ))}
        </div>

        <p className="text-center text-sm text-gray-500 mt-8">
          *Harga dapat berubah sewaktu-waktu. Hubungi kami untuk informasi terbaru dan promo.
        </p>
      </div>
    </section>
  );
}
