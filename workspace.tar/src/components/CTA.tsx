import { Sparkles } from 'lucide-react';

export default function CTA() {
  return (
    <section className="py-20 lg:py-28 gradient-hero relative overflow-hidden">
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-10">
        <div className="absolute top-10 left-20 w-40 h-40 bg-white rounded-full blur-2xl"></div>
        <div className="absolute bottom-10 right-20 w-60 h-60 bg-accent-400 rounded-full blur-3xl"></div>
      </div>

      <div className="relative max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <div className="inline-flex items-center gap-2 bg-white/10 backdrop-blur-sm px-4 py-2 rounded-full mb-6">
          <Sparkles className="w-4 h-4 text-accent-400" />
          <span className="text-sm font-medium text-white">Konsultasi Gratis!</span>
        </div>

        <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-white mb-6">
          Siap Meningkatkan Prestasi
          <br />
          <span className="text-accent-400">Anak Anda?</span>
        </h2>

        <p className="text-lg text-blue-100 mb-10 max-w-2xl mx-auto">
          Jangan tunda lagi! Daftarkan sekarang dan dapatkan konsultasi gratis untuk menentukan 
          guru terbaik yang sesuai dengan kebutuhan belajar.
        </p>

        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <a
            href="#kontak"
            className="inline-flex items-center justify-center gap-2 bg-accent-400 text-primary-900 px-8 py-4 rounded-full font-bold text-lg hover:bg-accent-500 transition-all shadow-xl"
          >
            Daftar Sekarang — Gratis!
          </a>
          <a
            href="https://wa.me/6287767681430"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center justify-center gap-2 bg-white/10 backdrop-blur-sm text-white px-8 py-4 rounded-full font-semibold text-lg hover:bg-white/20 transition-all border border-white/20"
          >
            💬 Chat WhatsApp
          </a>
        </div>
      </div>
    </section>
  );
}
