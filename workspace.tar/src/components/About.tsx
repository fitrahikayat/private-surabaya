import { Target, Users, Heart, Lightbulb } from 'lucide-react';

export default function About() {
  return (
    <section id="tentang" className="py-20 lg:py-28 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <span className="inline-block bg-primary-100 text-primary-700 px-4 py-1.5 rounded-full text-sm font-semibold mb-4">
            Tentang Kami
          </span>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-gray-900 mb-6">
            Mengapa <span className="text-gradient">Private Surabaya</span>?
          </h2>
          <p className="text-lg text-gray-600 leading-relaxed">
            Kami percaya setiap murid memiliki gaya belajar yang unik. Private Surabaya hadir sebagai jembatan 
            yang mempertemukan guru berkualitas dengan murid di rumah, dengan pendekatan yang sepenuhnya 
            mengikuti keinginan dan kebutuhan belajar murid.
          </p>
        </div>

        {/* Value Cards */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          <div className="group bg-gradient-to-br from-blue-50 to-white p-8 rounded-2xl border border-blue-100 hover:shadow-xl transition-all duration-300 hover:-translate-y-1">
            <div className="w-14 h-14 bg-primary-600 rounded-2xl flex items-center justify-center mb-5 group-hover:scale-110 transition-transform">
              <Target className="w-7 h-7 text-white" />
            </div>
            <h3 className="text-xl font-bold text-gray-900 mb-3">Sesuai Keinginan Murid</h3>
            <p className="text-gray-600 leading-relaxed">
              Murid menentukan arah belajar — dari mata pelajaran, materi, hingga metode. Guru menyesuaikan sepenuhnya.
            </p>
          </div>

          <div className="group bg-gradient-to-br from-green-50 to-white p-8 rounded-2xl border border-green-100 hover:shadow-xl transition-all duration-300 hover:-translate-y-1">
            <div className="w-14 h-14 bg-green-600 rounded-2xl flex items-center justify-center mb-5 group-hover:scale-110 transition-transform">
              <Users className="w-7 h-7 text-white" />
            </div>
            <h3 className="text-xl font-bold text-gray-900 mb-3">Guru Terseleksi</h3>
            <p className="text-gray-600 leading-relaxed">
              Semua guru kami melalui proses seleksi ketat untuk memastikan kualitas pengajaran terbaik bagi murid.
            </p>
          </div>

          <div className="group bg-gradient-to-br from-purple-50 to-white p-8 rounded-2xl border border-purple-100 hover:shadow-xl transition-all duration-300 hover:-translate-y-1">
            <div className="w-14 h-14 bg-purple-600 rounded-2xl flex items-center justify-center mb-5 group-hover:scale-110 transition-transform">
              <Heart className="w-7 h-7 text-white" />
            </div>
            <h3 className="text-xl font-bold text-gray-900 mb-3">Belajar Nyaman</h3>
            <p className="text-gray-600 leading-relaxed">
              Belajar di rumah sendiri membuat murid lebih rileks, fokus, dan nyaman sehingga materi lebih mudah diserap.
            </p>
          </div>

          <div className="group bg-gradient-to-br from-amber-50 to-white p-8 rounded-2xl border border-amber-100 hover:shadow-xl transition-all duration-300 hover:-translate-y-1">
            <div className="w-14 h-14 bg-amber-500 rounded-2xl flex items-center justify-center mb-5 group-hover:scale-110 transition-transform">
              <Lightbulb className="w-7 h-7 text-white" />
            </div>
            <h3 className="text-xl font-bold text-gray-900 mb-3">Metode Fleksibel</h3>
            <p className="text-gray-600 leading-relaxed">
              Jadwal dan metode belajar fleksibel menyesuaikan kesibukan murid. Bisa diatur sesuai kenyamanan.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}
