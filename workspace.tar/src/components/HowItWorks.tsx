import { ClipboardList, UserCheck, Calendar, BookOpenCheck } from 'lucide-react';

export default function HowItWorks() {
  const steps = [
    {
      icon: ClipboardList,
      step: '01',
      title: 'Daftar & Konsultasi',
      description: 'Hubungi kami dan ceritakan kebutuhan belajar murid. Tim kami akan membantu menentukan guru yang paling cocok.',
      color: 'bg-primary-600',
      lightColor: 'bg-primary-100',
    },
    {
      icon: UserCheck,
      step: '02',
      title: 'Matching Guru',
      description: 'Kami mencarikan guru yang sesuai dengan mata pelajaran, gaya belajar, dan preferensi murid.',
      color: 'bg-green-600',
      lightColor: 'bg-green-100',
    },
    {
      icon: Calendar,
      step: '03',
      title: 'Atur Jadwal',
      description: 'Tentukan jadwal dan frekuensi belajar yang sesuai dengan kesibukan murid. Sangat fleksibel!',
      color: 'bg-purple-600',
      lightColor: 'bg-purple-100',
    },
    {
      icon: BookOpenCheck,
      step: '04',
      title: 'Mulai Belajar',
      description: 'Guru datang ke rumah dan mulai belajar sesuai arahan murid. Progress dipantau secara berkala.',
      color: 'bg-amber-500',
      lightColor: 'bg-amber-100',
    },
  ];

  return (
    <section id="cara-kerja" className="py-20 lg:py-28 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <span className="inline-block bg-primary-100 text-primary-700 px-4 py-1.5 rounded-full text-sm font-semibold mb-4">
            Cara Kerja
          </span>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-gray-900 mb-6">
            Mudah & <span className="text-gradient">Simpel</span>
          </h2>
          <p className="text-lg text-gray-600">
            Hanya 4 langkah mudah untuk memulai perjalanan belajar bersama Private Surabaya
          </p>
        </div>

        {/* Steps */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {steps.map((step, index) => (
            <div key={index} className="relative">
              {/* Connector Line */}
              {index < steps.length - 1 && (
                <div className="hidden lg:block absolute top-12 left-[60%] w-full h-0.5 bg-gray-200 z-0"></div>
              )}

              <div className="relative bg-white rounded-2xl p-8 shadow-sm hover:shadow-lg transition-all duration-300 border border-gray-100 z-10">
                {/* Step Number */}
                <div className="absolute -top-3 -right-3 w-10 h-10 bg-gray-900 text-white rounded-full flex items-center justify-center text-sm font-bold">
                  {step.step}
                </div>

                {/* Icon */}
                <div className={`w-16 h-16 ${step.lightColor} rounded-2xl flex items-center justify-center mb-6`}>
                  <step.icon className={`w-8 h-8 ${step.color.replace('bg-', 'text-')}`} />
                </div>

                <h3 className="text-xl font-bold text-gray-900 mb-3">{step.title}</h3>
                <p className="text-gray-600 leading-relaxed">{step.description}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
