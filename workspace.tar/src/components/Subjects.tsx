import { Calculator, FlaskConical, Atom, Languages, BookOpen } from 'lucide-react';

export default function Subjects() {
  const subjects = [
    {
      icon: Calculator,
      name: 'Matematika',
      desc: 'Semua Jenjang (SD, SMP, SMA, UTBK)',
      color: 'from-blue-500 to-blue-700',
      highlights: ['Aljabar', 'Geometri', 'Kalkulus', 'Statistika'],
    },
    {
      icon: FlaskConical,
      name: 'Fisika',
      desc: 'Semua Jenjang (SMP, SMA, UTBK)',
      color: 'from-purple-500 to-purple-700',
      highlights: ['Mekanika', 'Listrik', 'Termodinamika', 'Gelombang'],
    },
    {
      icon: Atom,
      name: 'Biologi',
      desc: 'Semua Jenjang (SMP, SMA, UTBK)',
      color: 'from-green-500 to-green-700',
      highlights: ['Sel', 'Genetika', 'Ekologi', 'Sistem Tubuh'],
    },
    {
      icon: FlaskConical,
      name: 'Kimia',
      desc: 'Semua Jenjang (SMP, SMA, UTBK)',
      color: 'from-teal-500 to-teal-700',
      highlights: ['Organik', 'Anorganik', 'Stoikiometri', 'Reaksi'],
    },
    {
      icon: Languages,
      name: 'Bahasa Inggris',
      desc: 'Semua Jenjang (SD, SMP, SMA, Umum)',
      color: 'from-indigo-500 to-indigo-700',
      highlights: ['Grammar', 'Conversation', 'TOEFL', 'IELTS'],
    },
    {
      icon: BookOpen,
      name: 'Mengaji',
      desc: 'Semua Jenjang (Anak-anak hingga Dewasa)',
      color: 'from-emerald-500 to-emerald-700',
      highlights: ['Iqro', 'Tahsin', 'Tahfidz', 'Tajwid'],
    },
  ];

  return (
    <section id="mapel" className="py-20 lg:py-28 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <span className="inline-block bg-primary-100 text-primary-700 px-4 py-1.5 rounded-full text-sm font-semibold mb-4">
            Mata Pelajaran
          </span>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-gray-900 mb-6">
            Belajar Sesuai <span className="text-gradient">Keinginanmu</span>
          </h2>
          <p className="text-lg text-gray-600">
            Kami menyediakan 6 mata pelajaran unggulan untuk semua jenjang pendidikan. 
            Pilih yang kamu butuhkan, dan guru kami akan mengajar sesuai keinginanmu.
          </p>
        </div>

        {/* Subjects Grid */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {subjects.map((subject, index) => (
            <div
              key={index}
              className="group relative bg-white border border-gray-100 rounded-2xl p-6 hover:shadow-xl transition-all duration-300 hover:-translate-y-1 overflow-hidden"
            >
              {/* Background Gradient on Hover */}
              <div className={`absolute inset-0 bg-gradient-to-br ${subject.color} opacity-0 group-hover:opacity-5 transition-opacity duration-300`}></div>
              
              <div className="relative">
                <div className="flex items-start gap-4 mb-4">
                  <div className={`w-14 h-14 bg-gradient-to-br ${subject.color} rounded-xl flex items-center justify-center flex-shrink-0 group-hover:scale-110 transition-transform`}>
                    <subject.icon className="w-7 h-7 text-white" />
                  </div>
                  <div>
                    <h3 className="text-xl font-bold text-gray-900 mb-1">{subject.name}</h3>
                    <p className="text-sm text-gray-500">{subject.desc}</p>
                  </div>
                </div>

                {/* Highlights */}
                <div className="flex flex-wrap gap-2 mt-4">
                  {subject.highlights.map((item, i) => (
                    <span
                      key={i}
                      className="text-xs font-medium bg-gray-100 text-gray-600 px-3 py-1 rounded-full group-hover:bg-primary-50 group-hover:text-primary-700 transition-colors"
                    >
                      {item}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Additional Info */}
        <div className="mt-12 bg-primary-50 rounded-2xl p-8 text-center border border-primary-100">
          <p className="text-primary-800 font-semibold text-lg mb-2">
            🎯 Semua mata pelajaran tersedia untuk semua jenjang!
          </p>
          <p className="text-primary-600 text-sm">
            Dari SD, SMP, SMA, hingga persiapan UTBK/SNBT. Arah belajar sepenuhnya ditentukan oleh murid.
          </p>
        </div>
      </div>
    </section>
  );
}
