import { BookOpen, Instagram, Facebook, Youtube } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="bg-gray-900 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-12">
          {/* Brand */}
          <div className="lg:col-span-1">
            <div className="flex items-center gap-2 mb-4">
              <div className="w-10 h-10 bg-primary-600 rounded-xl flex items-center justify-center">
                <BookOpen className="w-6 h-6 text-white" />
              </div>
              <div>
                <span className="text-lg font-bold text-white">Private</span>
                <span className="text-lg font-bold text-accent-400"> Surabaya</span>
              </div>
            </div>
            <p className="text-gray-400 text-sm leading-relaxed mb-6">
              Layanan les private ke rumah di Surabaya. Menghubungkan guru terbaik dengan murid 
              untuk pengalaman belajar yang personal dan efektif.
            </p>
            <div className="flex gap-3">
              <a href="#" className="w-9 h-9 bg-gray-800 rounded-lg flex items-center justify-center hover:bg-primary-600 transition-colors">
                <Instagram className="w-4 h-4" />
              </a>
              <a href="#" className="w-9 h-9 bg-gray-800 rounded-lg flex items-center justify-center hover:bg-primary-600 transition-colors">
                <Facebook className="w-4 h-4" />
              </a>
              <a href="#" className="w-9 h-9 bg-gray-800 rounded-lg flex items-center justify-center hover:bg-primary-600 transition-colors">
                <Youtube className="w-4 h-4" />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="font-bold text-white mb-4">Menu</h4>
            <ul className="space-y-3">
              <li><a href="#beranda" className="text-gray-400 text-sm hover:text-white transition-colors">Beranda</a></li>
              <li><a href="#tentang" className="text-gray-400 text-sm hover:text-white transition-colors">Tentang Kami</a></li>
              <li><a href="#cara-kerja" className="text-gray-400 text-sm hover:text-white transition-colors">Cara Kerja</a></li>
              <li><a href="#mapel" className="text-gray-400 text-sm hover:text-white transition-colors">Mata Pelajaran</a></li>
              <li><a href="#harga" className="text-gray-400 text-sm hover:text-white transition-colors">Paket Harga</a></li>
            </ul>
          </div>

          {/* Subjects */}
          <div>
            <h4 className="font-bold text-white mb-4">Mata Pelajaran</h4>
            <ul className="space-y-3">
              <li><span className="text-gray-400 text-sm">Matematika</span></li>
              <li><span className="text-gray-400 text-sm">Fisika</span></li>
              <li><span className="text-gray-400 text-sm">Biologi</span></li>
              <li><span className="text-gray-400 text-sm">Kimia</span></li>
              <li><span className="text-gray-400 text-sm">Bahasa Inggris</span></li>
              <li><span className="text-gray-400 text-sm">Mengaji</span></li>
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h4 className="font-bold text-white mb-4">Kontak</h4>
            <ul className="space-y-3">
              <li className="text-gray-400 text-sm">📞 0877-6768-1430</li>
              <li className="text-gray-400 text-sm">✉️ privatesurabaya22@gmail.com</li>
              <li className="text-gray-400 text-sm">📍 Jl. Mulyorejo Tengah No.53, Mulyorejo, Surabaya</li>
              <li className="text-gray-400 text-sm">🕐 Senin - Sabtu, 08:00 - 21:00</li>
            </ul>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="border-t border-gray-800 mt-12 pt-8 flex flex-col md:flex-row items-center justify-between gap-4">
          <p className="text-gray-500 text-sm">
            © 2024 Private Surabaya. All rights reserved.
          </p>
          <div className="flex gap-6">
            <a href="#" className="text-gray-500 text-sm hover:text-white transition-colors">Syarat & Ketentuan</a>
            <a href="#" className="text-gray-500 text-sm hover:text-white transition-colors">Kebijakan Privasi</a>
          </div>
        </div>
      </div>
    </footer>
  );
}
