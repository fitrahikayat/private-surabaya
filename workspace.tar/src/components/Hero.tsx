import { ArrowRight, Home, GraduationCap, Star } from 'lucide-react';

export default function Hero() {
  return (
    <section id="beranda" className="relative min-h-screen flex items-center gradient-hero overflow-hidden">
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-10">
        <div className="absolute top-20 left-10 w-72 h-72 bg-white rounded-full blur-3xl"></div>
        <div className="absolute bottom-20 right-10 w-96 h-96 bg-accent-400 rounded-full blur-3xl"></div>
        <div className="absolute top-1/2 left-1/2 w-64 h-64 bg-primary-300 rounded-full blur-3xl"></div>
      </div>

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-24 pb-16">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Left Content */}
          <div className="text-white animate-fade-in">
            <div className="inline-flex items-center gap-2 bg-white/10 backdrop-blur-sm px-4 py-2 rounded-full mb-6">
              <Star className="w-4 h-4 text-accent-400 fill-accent-400" />
              <span className="text-sm font-medium">Les Private #1 di Surabaya</span>
            </div>

            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold leading-tight mb-6">
              Guru Datang ke
              <span className="text-accent-400"> Rumah</span>,
              <br />
              Murid Belajar
              <span className="text-accent-400"> Nyaman</span>
            </h1>

            <p className="text-lg sm:text-xl text-blue-100 mb-8 max-w-lg">
              Private Surabaya mempertemukan guru terbaik dengan murid untuk belajar di rumah. 
              Arah belajar sepenuhnya sesuai keinginan murid — fleksibel, personal, dan efektif.
            </p>

            <div className="flex flex-col sm:flex-row gap-4 mb-12">
              <a
                href="#kontak"
                className="inline-flex items-center justify-center gap-2 bg-accent-400 text-primary-900 px-8 py-4 rounded-full font-bold text-lg hover:bg-accent-500 transition-all shadow-xl hover:shadow-2xl hover:-translate-y-0.5"
              >
                Mulai Belajar
                <ArrowRight className="w-5 h-5" />
              </a>
              <a
                href="#cara-kerja"
                className="inline-flex items-center justify-center gap-2 bg-white/10 backdrop-blur-sm text-white px-8 py-4 rounded-full font-semibold text-lg hover:bg-white/20 transition-all border border-white/20"
              >
                Pelajari Lebih Lanjut
              </a>
            </div>

            {/* Stats */}
            <div className="grid grid-cols-3 gap-6">
              <div>
                <div className="text-3xl font-bold text-accent-400">500+</div>
                <div className="text-sm text-blue-200">Murid Aktif</div>
              </div>
              <div>
                <div className="text-3xl font-bold text-accent-400">200+</div>
                <div className="text-sm text-blue-200">Guru Profesional</div>
              </div>
              <div>
                <div className="text-3xl font-bold text-accent-400">98%</div>
                <div className="text-sm text-blue-200">Kepuasan</div>
              </div>
            </div>
          </div>

          {/* Right Content - Illustration */}
          <div className="hidden lg:flex justify-center">
            <div className="relative">
              {/* Main Card */}
              <div className="bg-white rounded-3xl p-8 shadow-2xl max-w-sm animate-float">
                <div className="flex items-center gap-4 mb-6">
                  <div className="w-14 h-14 bg-primary-100 rounded-2xl flex items-center justify-center">
                    <Home className="w-7 h-7 text-primary-600" />
                  </div>
                  <div>
                    <h3 className="font-bold text-gray-800">Belajar di Rumah</h3>
                    <p className="text-sm text-gray-500">Nyaman & Fokus</p>
                  </div>
                </div>
                <div className="space-y-3">
                  <div className="flex items-center gap-3 bg-green-50 p-3 rounded-xl">
                    <div className="w-8 h-8 bg-green-500 rounded-full flex items-center justify-center">
                      <span className="text-white text-xs">✓</span>
                    </div>
                    <span className="text-sm font-medium text-gray-700">Guru datang sesuai jadwal</span>
                  </div>
                  <div className="flex items-center gap-3 bg-blue-50 p-3 rounded-xl">
                    <div className="w-8 h-8 bg-blue-500 rounded-full flex items-center justify-center">
                      <span className="text-white text-xs">✓</span>
                    </div>
                    <span className="text-sm font-medium text-gray-700">Materi sesuai keinginan murid</span>
                  </div>
                  <div className="flex items-center gap-3 bg-purple-50 p-3 rounded-xl">
                    <div className="w-8 h-8 bg-purple-500 rounded-full flex items-center justify-center">
                      <span className="text-white text-xs">✓</span>
                    </div>
                    <span className="text-sm font-medium text-gray-700">Progress terpantau</span>
                  </div>
                </div>
              </div>

              {/* Floating Badge */}
              <div className="absolute -top-4 -right-4 bg-accent-400 text-primary-900 px-4 py-2 rounded-full font-bold text-sm shadow-lg animate-float" style={{ animationDelay: '1s' }}>
                <GraduationCap className="w-4 h-4 inline mr-1" />
                100% Personal
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Wave Bottom */}
      <div className="absolute bottom-0 left-0 right-0">
        <svg viewBox="0 0 1440 120" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M0 120L60 110C120 100 240 80 360 70C480 60 600 60 720 65C840 70 960 80 1080 85C1200 90 1320 90 1380 90L1440 90V120H1380C1320 120 1200 120 1080 120C960 120 840 120 720 120C600 120 480 120 360 120C240 120 120 120 60 120H0Z" fill="white"/>
        </svg>
      </div>
    </section>
  );
}
