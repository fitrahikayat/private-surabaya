import { Star, Quote } from 'lucide-react';

export default function Testimonials() {
  const testimonials = [
    {
      name: 'Anisa Rahma',
      role: 'Siswa SMA Kelas 12',
      text: 'Guru yang datang sangat sabar dan cara mengajarnya mudah dipahami. Nilai matematika saya naik drastis setelah les di Private Surabaya!',
      rating: 5,
      initial: 'AR',
      color: 'bg-pink-500',
    },
    {
      name: 'Budi Santoso',
      role: 'Orang Tua Murid SMP',
      text: 'Anak saya jadi lebih semangat belajar karena gurunya asik dan jadwalnya fleksibel. Progress report-nya juga sangat membantu kami memantau.',
      rating: 5,
      initial: 'BS',
      color: 'bg-blue-500',
    },
    {
      name: 'Dina Kartika',
      role: 'Mahasiswa - Persiapan UTBK',
      text: 'Saya bisa fokus belajar sesuai target kampus yang saya mau. Gurunya expert di bidangnya dan materinya terstruktur dengan baik.',
      rating: 5,
      initial: 'DK',
      color: 'bg-purple-500',
    },
    {
      name: 'Rizky Pratama',
      role: 'Siswa SMP Kelas 8',
      text: 'Belajar fisika jadi seru! Gurunya pakai cara yang gampang dimengerti. Sekarang saya jadi suka fisika, padahal sebelumnya susah banget.',
      rating: 5,
      initial: 'RP',
      color: 'bg-green-500',
    },
    {
      name: 'Ibu Wulandari',
      role: 'Orang Tua Murid SD',
      text: 'Anak saya yang tadinya malas belajar, sekarang malah nunggu-nunggu gurunya datang. Terima kasih Private Surabaya!',
      rating: 5,
      initial: 'IW',
      color: 'bg-amber-500',
    },
    {
      name: 'Fajar Nugroho',
      role: 'Siswa SMA - Persiapan SNBT',
      text: 'Jadwalnya fleksibel banget, bisa disesuaikan dengan kegiatan sekolah saya. Gurunya juga selalu kasih tips dan trik mengerjakan soal.',
      rating: 5,
      initial: 'FN',
      color: 'bg-indigo-500',
    },
  ];

  return (
    <section id="testimoni" className="py-20 lg:py-28 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <span className="inline-block bg-primary-100 text-primary-700 px-4 py-1.5 rounded-full text-sm font-semibold mb-4">
            Testimoni
          </span>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-gray-900 mb-6">
            Kata <span className="text-gradient">Mereka</span>
          </h2>
          <p className="text-lg text-gray-600">
            Dengarkan pengalaman dari murid dan orang tua yang sudah merasakan layanan Private Surabaya
          </p>
        </div>

        {/* Testimonials Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {testimonials.map((item, index) => (
            <div
              key={index}
              className="bg-gray-50 rounded-2xl p-8 border border-gray-100 hover:shadow-lg transition-all duration-300 relative"
            >
              {/* Quote Icon */}
              <Quote className="w-8 h-8 text-primary-200 absolute top-6 right-6" />

              {/* Stars */}
              <div className="flex gap-1 mb-4">
                {Array.from({ length: item.rating }).map((_, i) => (
                  <Star key={i} className="w-4 h-4 text-accent-500 fill-accent-500" />
                ))}
              </div>

              {/* Text */}
              <p className="text-gray-700 leading-relaxed mb-6 italic">"{item.text}"</p>

              {/* Author */}
              <div className="flex items-center gap-3">
                <div className={`w-10 h-10 ${item.color} rounded-full flex items-center justify-center`}>
                  <span className="text-white text-sm font-bold">{item.initial}</span>
                </div>
                <div>
                  <h4 className="font-semibold text-gray-900 text-sm">{item.name}</h4>
                  <p className="text-xs text-gray-500">{item.role}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
